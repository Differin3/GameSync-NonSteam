import logging
import os
import re
import configparser
import time
from difflib import SequenceMatcher
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

logger = logging.getLogger(__name__)

# Использование кэша
use_cache = True

# Найденные корни (ключ — домашний каталог), чтобы не сканировать повторно.
_ROOT_CACHE: Dict[str, Path] = {}

# Каталоги, которые точно не являются PortProton и могут быть огромными.
_SKIP_ROOT_DIRS = {
    "steam", "steamapps", "steamrt", "node_modules", "snap", "flatpak",
    "documents", "downloads", "music", "pictures", "videos", "tmp",
}

# Возможные корни PortProton (по приоритету)
PORTPROTON_ROOT_CANDIDATES = [
    "PortProton",
    ".PortProton",
    ".local/share/PortProton",
]

# Шаблоны папок внутри Windows-профиля, где игры обычно хранят сохранения.
SAVE_ROOT_TEMPLATES = [
    "Documents/My Games",
    "Documents",
    "Saved Games",
    "AppData/LocalLow",
    "AppData/Local",
    "AppData/Roaming",
]

# Пользователи Windows, которых проверяем, если не удалось определить динамически.
FALLBACK_WINDOWS_USERS = ["steamuser", "deck", "user", "Public"]

# Стандартные пути (оставлено для обратной совместимости / внешнего использования).
# Строится из списка типовых профилей, а не из одного жёстко заданного пользователя.
STANDARD_SAVE_PATHS = [
    f"users/{user}/{subdir}"
    for user in FALLBACK_WINDOWS_USERS
    if user != "Public"
    for subdir in (
        "Documents",
        "Documents/My Games",
        "Saved Games",
        "AppData/Local",
        "AppData/Roaming",
    )
]

# Расширения файлов сохранений
# Служебные файлы: логи, картинки, бинарники — это не сохранения.
SERVICE_EXTENSIONS = {
    ".log", ".txt", ".dll", ".exe", ".png", ".jpg", ".jpeg", ".dds", ".pdb",
    ".mdmp", ".wer", ".chunk", ".pak",
}

# Папки Steam-эмуляторов в AppData/Roaming: <EMU>/<appid>/remote — сохранения.
EMULATOR_DIRS = {
    "hoodlum", "codex", "goldberg", "gse", "skidrow", "reloaded", "plaza",
    "empress", "rune", "tenoke", "flt", "razor1911", "elamigos", "prophet",
}

SAVE_EXTENSIONS = {
    ".sav", ".save", ".sav0", ".sav1", ".sav2", ".slot", ".dat", ".cfg",
    ".ini", ".json", ".xml", ".profile", ".es3", ".ess", ".d2s", ".nhl",
    ".rsv", ".sgs", ".gsv", ".ugc", ".bak",
}

# Частые служебные папки, которые не являются сохранениями.
IGNORED_FOLDER_NAMES = {
    "microsoft", "windows", "temp", "tmp", "cache", "crashdumps", "packages",
    "nvidia", "intel", "amd", "d3dcompiler", "logs", "log", "crashpad",
    "google", "mozilla", "wine", "proton",
}

# Служебные .desktop файлы, которые нужно игнорировать
IGNORED_DESKTOP_FILES = {"portproton.desktop", "readme.desktop"}

# Общие имена, которые не являются названиями игр
GENERIC_GAME_NAMES = {"portproton", "wine", "proton", "readme", "game", "launcher", "default", "dotnet"}

# Слова, по которым запись считается не игрой (саундтреки, артбуки).
NON_GAME_WORDS = {"soundtrack", "artwork", "artbook", "digital art", "bonus content"}

# Финальные «издания», которые не входят в имя папки сохранений.
_EDITION_SUFFIXES = [
    "game of the year edition", "goty edition", "game of the year", "goty",
    "definitive edition", "complete edition", "ultimate edition",
    "deluxe edition", "enhanced edition", "gold edition", "premium edition",
    "collectors edition", "collector's edition", "special edition",
    "definitive", "remastered", "remaster",
]


def _looks_like_portproton_root(path: Path) -> bool:
    """Узнаём PortProton по структуре, а не только по имени папки."""
    try:
        return (path / "data" / "scripts" / "start.sh").is_file() or (
            path / "steam_scripts"
        ).is_dir()
    except OSError:
        return False


def _discover_portproton_root(home: Path) -> Optional[Path]:
    """Поиск перенесённой/переименованной папки PortProton (глубина 2)."""
    try:
        children = list(home.iterdir())
    except OSError:
        return None
    for child in children:
        if not child.is_dir() or child.name.startswith("."):
            continue
        if _looks_like_portproton_root(child):
            return child
        if child.name.lower() in _SKIP_ROOT_DIRS:
            continue
        try:
            subs = list(child.iterdir())
        except OSError:
            continue
        for sub in subs:
            if sub.is_dir() and not sub.name.startswith(".") and _looks_like_portproton_root(sub):
                return sub
    return None


def find_portproton_root() -> Optional[Path]:
    """Найти корневую папку PortProton."""
    home = Path.home()
    cache_key = str(home)
    cached = _ROOT_CACHE.get(cache_key)
    if cached and cached.is_dir():
        return cached

    env_root = os.environ.get("PORTPROTON_ROOT", "").strip()
    if env_root:
        candidate = Path(env_root).expanduser()
        if candidate.is_dir():
            _ROOT_CACHE[cache_key] = candidate
            return candidate

    for rel in PORTPROTON_ROOT_CANDIDATES:
        candidate = home / rel
        if candidate.exists() and candidate.is_dir():
            _ROOT_CACHE[cache_key] = candidate
            return candidate

    discovered = _discover_portproton_root(home)
    if discovered:
        logger.info(f"PortProton root discovered at {discovered}")
        _ROOT_CACHE[cache_key] = discovered
        return discovered

    logger.warning(f"PortProton root not found under {home}")
    return None


def get_portproton_prefixes_path() -> Optional[Path]:
    """Получить путь к папке префиксов PortProton."""
    root = find_portproton_root()
    if not root:
        return None
    for rel in ("prefixes", "data/prefixes"):
        candidate = root / rel
        if candidate.exists() and candidate.is_dir():
            return candidate
    return root / "prefixes"


# ---------------------------------------------------------------------------
# Нормализация и сравнение имён
# ---------------------------------------------------------------------------

def _normalize(text: str) -> str:
    """lowercase + только буквы/цифры/пробелы."""
    return "".join(c for c in (text or "").lower() if c.isalnum() or c.isspace()).strip()


def _normalize_title(text: str) -> str:
    """Нормализация названия с отсечением финальных слов-изданий (GOTY, Deluxe...)."""
    norm = _normalize(text)
    if not norm:
        return ""
    changed = True
    while changed:
        changed = False
        for suffix in _EDITION_SUFFIXES:
            if norm != suffix and norm.endswith(" " + suffix):
                norm = norm[: -(len(suffix) + 1)].strip()
                changed = True
                break
    return norm or _normalize(text)


def _similarity(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a, b).ratio()


def _word_boundary_match(short: str, long: str) -> bool:
    """Есть ли `short` в `long` на границе слова (не внутри слова)."""
    idx = long.find(short)
    while idx != -1:
        before = long[idx - 1] if idx > 0 else " "
        after = long[idx + len(short)] if idx + len(short) < len(long) else " "
        if not before.isalnum() and not after.isalnum():
            return True
        idx = long.find(short, idx + 1)
    return False


def _name_match_score(game_name: str, folder_name: str) -> int:
    """Оценка совпадения имени игры и папки (0..100)."""
    a = _normalize_title(game_name)
    b = _normalize_title(folder_name)
    if not a or not b:
        return 0
    if a == b:
        return 100

    # Сравнение без пробелов: "Test Game" == "TestGame"
    a_flat = a.replace(" ", "")
    b_flat = b.replace(" ", "")
    if a_flat and a_flat == b_flat:
        return 95

    # Вхождение на границе слова (Doom -> Doom Eternal), но не Star -> Starfield
    if len(a) >= 4 and _word_boundary_match(a, b):
        return 80
    if len(b) >= 4 and _word_boundary_match(b, a):
        return 80

    # Вхождение без пробелов, но только для достаточно длинных строк
    if len(a_flat) >= 5 and a_flat in b_flat:
        return 78
    if len(b_flat) >= 5 and b_flat in a_flat:
        return 78

    a_words = {w for w in a.split() if len(w) >= 3}
    b_words = {w for w in b.split() if len(w) >= 3}
    if a_words and b_words and (a_words <= b_words or b_words <= a_words):
        return 65

    sim = _similarity(a_flat, b_flat)
    if sim >= 0.85:
        return int(50 * sim)
    return 0


def _names_match(game_name: str, folder_name: str) -> bool:
    """Совпадают ли имена (точное, вхождение, слова или нечёткое сходство)."""
    return _name_match_score(game_name, folder_name) > 0


# ---------------------------------------------------------------------------
# Парсинг .desktop
# ---------------------------------------------------------------------------

def parse_desktop_file(desktop_path: Path) -> Optional[Dict[str, str]]:
    """Парсинг .desktop файла.

    - поддерживает локализованные имена Name[xx];
    - отключает интерполяцию configparser, иначе строки вида %U/%f в Exec
      ломают разбор и игра не находится;
    - отбрасывает служебные/общие записи.
    """
    try:
        parser = configparser.ConfigParser(interpolation=None, strict=False)
        with open(desktop_path, "r", encoding="utf-8", errors="replace") as f:
            parser.read_file(f)

        if "Desktop Entry" not in parser:
            return None

        entry = parser["Desktop Entry"]

        name = entry.get("Name")
        if not name:
            for key, value in entry.items():
                if key.lower().startswith("name[") and value:
                    name = value
                    break
        if not name:
            name = desktop_path.stem

        name = name.strip()
        if not name or name.lower() in GENERIC_GAME_NAMES:
            return None

        return {
            "name": name,
            "exec": entry.get("Exec", "").strip(),
            "try_exec": entry.get("TryExec", "").strip(),
            "comment": entry.get("Comment", "").strip(),
            "icon": entry.get("Icon", "").strip(),
            "desktop_file": str(desktop_path),
        }
    except Exception as e:
        logger.error(f"Error parsing desktop file {desktop_path}: {e}")
        return None


# ---------------------------------------------------------------------------
# Поиск префикса игры
# ---------------------------------------------------------------------------

def _iter_prefixes(prefixes_path: Path) -> List[Path]:
    if not prefixes_path or not prefixes_path.is_dir():
        return []
    result = []
    try:
        for item in prefixes_path.iterdir():
            if item.is_dir() and (item / "drive_c").exists():
                result.append(item)
    except (PermissionError, OSError) as e:
        logger.debug(f"Cannot list prefixes in {prefixes_path}: {e}")
    return result


def _prefix_hint_from_exec(exec_cmd: str) -> Optional[str]:
    """Пытается вытащить имя префикса из команды Exec."""
    if not exec_cmd:
        return None
    for token in exec_cmd.replace('"', " ").replace("'", " ").split():
        normalized = token.replace("\\", "/")
        if "/prefixes/" in normalized:
            tail = normalized.split("/prefixes/", 1)[1].strip("/")
            if tail:
                return tail.split("/")[0]
    return None


def _prefix_hint_from_path(path: str) -> Optional[str]:
    """Имя префикса из произвольного пути (StartDir/Exe ярлыка Steam)."""
    if not path:
        return None
    normalized = path.replace("\\", "/")
    if "prefixes/" not in normalized:
        return None
    tail = normalized.split("prefixes/", 1)[1].strip("/")
    return tail.split("/")[0] if tail else None


def find_prefix_for_game(
    game_name: str,
    desktop_file_path: str,
    prefixes_path: Path,
    exec_cmd: str = "",
    hint_path: str = "",
) -> Optional[Path]:
    """Найти префикс для игры по имени, .desktop, Exec и подсказке пути."""
    prefixes = _iter_prefixes(prefixes_path)
    if not prefixes:
        return None

    desktop_stem = Path(desktop_file_path).stem if desktop_file_path else ""
    targets = [
        t for t in (
            game_name,
            desktop_stem,
            _prefix_hint_from_exec(exec_cmd),
            _prefix_hint_from_path(hint_path),
        ) if t
    ]

    best: Optional[Path] = None
    best_score = 0
    for prefix in prefixes:
        if prefix.name.upper() == "DEFAULT":
            continue
        for target in targets:
            score = _name_match_score(target, prefix.name)
            if score > best_score:
                best_score = score
                best = prefix

    if best and best_score >= 65:
        return best

    # DEFAULT префикс как fallback (многие игры PortProton используют его)
    default_prefix = prefixes_path / "DEFAULT"
    if default_prefix.exists() and (default_prefix / "drive_c").exists():
        logger.debug(f"Using DEFAULT prefix for game '{game_name}'")
        return default_prefix

    logger.debug(f"Prefix not found for game '{game_name}', desktop: {desktop_file_path}")
    return None


# ---------------------------------------------------------------------------
# Поиск путей сохранений
# ---------------------------------------------------------------------------

def _list_windows_users(drive_c: Path) -> List[str]:
    users_dir = drive_c / "users"
    names: List[str] = []
    if users_dir.is_dir():
        try:
            for item in users_dir.iterdir():
                if item.is_dir():
                    names.append(item.name)
        except (PermissionError, OSError):
            pass
    for user in FALLBACK_WINDOWS_USERS:
        if user not in names and (users_dir / user).is_dir():
            names.append(user)
    return names or FALLBACK_WINDOWS_USERS[:2]


def _folder_stats(folder: Path) -> Tuple[int, int, int, float, int]:
    """(всего файлов, файлов-сохранений, размер, mtime, неслужебных файлов)."""
    total = 0
    save_files = 0
    size = 0
    newest = 0.0
    meaningful = 0
    try:
        for path in folder.rglob("*"):
            if not path.is_file():
                continue
            total += 1
            suffix = path.suffix.lower()
            if suffix in SAVE_EXTENSIONS:
                save_files += 1
            if suffix not in SERVICE_EXTENSIONS:
                meaningful += 1
            try:
                stat = path.stat()
                size += stat.st_size
                newest = max(newest, stat.st_mtime)
            except OSError:
                pass
            if total >= 3000:
                break
    except (PermissionError, OSError):
        pass
    return total, save_files, size, newest, meaningful


def _score_candidate(name_score: int, total: int, save_files: int, size: int, newest: float, depth: int) -> int:
    score = name_score
    if save_files > 0:
        score += 25 + min(save_files, 25)
    elif total > 0:
        score += 8
    if size > 0:
        score += 5
    if newest and (time.time() - newest) < 30 * 86400:
        score += 10
    if depth >= 2:
        score += 3
    return score


def _find_named_dirs(root: Path, game_name: str, max_depth: int = 3, max_dirs: int = 800) -> List[Tuple[Path, int, int]]:
    """Найти папки с именем игры под root. Возвращает (path, name_score, depth)."""
    matches: List[Tuple[Path, int, int]] = []
    if not root.is_dir():
        return matches

    visited = 0
    stack: List[Tuple[Path, int]] = [(root, 1)]
    while stack:
        current, depth = stack.pop()
        try:
            entries = list(current.iterdir())
        except (PermissionError, OSError):
            continue
        for item in entries:
            if not item.is_dir():
                continue
            if item.name.lower() in IGNORED_FOLDER_NAMES:
                continue
            visited += 1
            if visited > max_dirs:
                return matches

            score = _name_match_score(game_name, item.name)
            if score > 0:
                matches.append((item, score, depth))
                continue  # не заходим внутрь найденной папки
            if depth < max_depth:
                stack.append((item, depth + 1))
    return matches


def _candidate_roots(drive_c: Path) -> List[Path]:
    roots: List[Path] = []
    for user in _list_windows_users(drive_c):
        base = drive_c / "users" / user
        for template in SAVE_ROOT_TEMPLATES:
            roots.append(base / template)
    roots.append(drive_c / "ProgramData")
    return roots


def _resolve_known_rel(drive_c: Path, rel: str, users: List[str]) -> Optional[Path]:
    """Разрешить известный относительный путь, подставив реального Windows-пользователя."""
    rel = rel.replace("\\", "/").lstrip("/")
    direct = drive_c / rel
    if direct.exists():
        return direct.parent if direct.is_file() else direct

    parts = rel.split("/")
    if len(parts) >= 3 and parts[0].lower() == "users":
        rest = "/".join(parts[2:])
        for user in users:
            candidate = drive_c / "users" / user / rest
            if candidate.exists():
                return candidate.parent if candidate.is_file() else candidate
    return None



def _extract_exe_path(exec_cmd: str) -> str:
    """Путь к .exe из строки Exec (в кавычках или без)."""
    if not exec_cmd:
        return ""
    import re
    quoted = re.findall(r'"([^"]+?\.exe)"', exec_cmd, re.IGNORECASE)
    if quoted:
        return quoted[-1]
    match = re.search(r'(\S+?\.exe)', exec_cmd, re.IGNORECASE)
    return match.group(1) if match else ""


def detect_real_steam_appid(exec_cmd: str) -> Optional[int]:
    """Настоящий Steam App ID из steam_appid.txt рядом с игрой (Goldberg).

    В отличие от App ID ярлыка (≈3.3 млрд) это реальный идентификатор игры,
    по которому Ludusavi и OpenCloudSaves находят точные пути сохранений.
    """
    exe = _extract_exe_path(exec_cmd)
    if not exe:
        return None
    exe_path = Path(exe)
    search_dirs = [exe_path.parent]
    parent = exe_path.parent
    for _ in range(2):
        parent = parent.parent
        search_dirs.append(parent)

    for directory in search_dirs:
        for candidate in (directory / "steam_appid.txt", directory / "steam_settings" / "steam_appid.txt"):
            try:
                if not candidate.is_file():
                    continue
                raw = candidate.read_text(encoding="utf-8", errors="ignore").strip()
                value = int(raw.split()[0])
            except (OSError, ValueError, IndexError):
                continue
            # Реальные App ID < 3 000 000; у ярлыков Steam они ~3.3e9
            if 0 < value < 3_000_000:
                return value
    return None


EMU_INI_NAMES = (
    "steam_emu.ini", "steam_api.ini", "steam_api64.ini",
    "codex.ini", "rune.ini", "ali213.ini", "coldclient.ini",
)


def _emu_ini_rel_path(exec_cmd: str) -> str:
    """Путь сейвов, который эмулятор прописывает в steam_emu.ini (%SystemDrive%)."""
    exe = _extract_exe_path(exec_cmd)
    if not exe:
        return ""
    base = Path(exe).parent
    for name in EMU_INI_NAMES:
        ini = base / name
        if not ini.is_file():
            continue
        try:
            raw = ini.read_bytes()
        except OSError:
            continue
        text = raw.decode("utf-8", errors="ignore") + "\n" + raw.decode("cp1251", errors="ignore")
        marker = "%SystemDrive%"
        idx = text.lower().find(marker.lower())
        while idx != -1:
            tail = text[idx + len(marker):]
            line = tail.splitlines()[0] if tail else ""
            rel = line.strip().strip('"').lstrip("\\/").strip()
            if rel:
                return rel.replace("\\", "/")
            idx = text.lower().find(marker.lower(), idx + len(marker))
    return ""


def _resolve_case_insensitive(base: Path, rel: str) -> Optional[Path]:
    """Найти путь внутри base без учёта регистра (Windows-пути в ini)."""
    current = base
    for part in rel.replace("\\", "/").split("/"):
        if not part:
            continue
        try:
            match = next((item for item in current.iterdir() if item.name.lower() == part.lower()), None)
        except (PermissionError, OSError):
            return None
        if match is None:
            return None
        current = match
    return current


SAVE_DIR_NAMES = {
    "save", "saves", "savedata", "savegames", "saved games", "savegame",
    "profile", "profiles", "player", "userdata", "user data",
}


SAVE_NAME_HINTS = ("save", "saved", "profile", "player", "slot", "progress")


def _dir_has_save_files(directory: Path) -> bool:
    """Есть ли в папке (без рекурсии) файлы, похожие на сохранения."""
    try:
        for child in directory.iterdir():
            if not child.is_file():
                continue
            suffix = child.suffix.lower()
            name = child.name.lower()
            if suffix in (".sav", ".save", ".sav0", ".sav1", ".sav2"):
                return True
            if any(hint in name for hint in SAVE_NAME_HINTS) and suffix in SAVE_EXTENSIONS:
                return True
    except (PermissionError, OSError):
        return False
    return False


def _install_dir_candidates(exec_cmd: str) -> List[Path]:
    """Папки сохранений рядом с exe игры (save/saves/profile/Data/...)."""
    exe = _extract_exe_path(exec_cmd)
    if not exe:
        return []
    base = Path(exe).parent
    results: List[Path] = []
    seen = set()

    # Папка exe и её непосредственные подпапки: в них ищем файлы-сейвы
    # (например, Spelunky/Data/spelunky_save.sav).
    candidates: List[Path] = [base]
    try:
        for child in base.iterdir():
            if child.is_dir():
                candidates.append(child)
    except (PermissionError, OSError):
        pass

    for directory in candidates:
        try:
            if not directory.is_dir():
                continue
            if _dir_has_save_files(directory):
                key = str(directory)
                if key not in seen:
                    seen.add(key)
                    results.append(directory)
        except (PermissionError, OSError):
            continue
    return results


def _steam_userdata_dirs(steam_appid, roots=None) -> List[Path]:
    """Папки Steam userdata/<uid>/<appid>/remote для реального App ID."""
    if not steam_appid:
        return []
    if roots is None:
        roots = [
            Path.home() / ".local" / "share" / "Steam" / "userdata",
            Path.home() / ".steam" / "steam" / "userdata",
        ]
    results: List[Path] = []
    for root in roots:
        try:
            if not Path(root).is_dir():
                continue
            for uid in Path(root).iterdir():
                remote = uid / str(steam_appid) / "remote"
                if remote.is_dir():
                    results.append(remote)
        except (PermissionError, OSError):
            continue
    return results


def _known_save_paths(game_name: str, steam_appid=None) -> List[str]:
    try:
        from game_definitions import get_known_save_paths_for_game
    except ImportError:
        return []
    if not game_name:
        return []
    try:
        return get_known_save_paths_for_game(game_name, steam_appid)
    except Exception as e:
        logger.warning(f"Error in game_definitions for '{game_name}': {e}")
        return []


def detect_save_candidates(game_prefix_path: Path, game_name: str = "", steam_appid=None, exec_cmd: str = "") -> List[Dict[str, Any]]:
    """Вернуть отсортированные кандидаты путей сохранений с оценкой.

    Каждый кандидат: {path, score, source, reason, fileCount, saveFileCount, size}.
    """
    drive_c = game_prefix_path / "drive_c"
    if not drive_c.exists():
        return []

    prefix_name = game_prefix_path.name
    users = _list_windows_users(drive_c)
    candidates: Dict[str, Dict[str, Any]] = {}

    def add(path: Path, name_score: int, source: str, depth: int, reason: str) -> None:
        key = str(path)
        total, save_files, size, newest, meaningful = _folder_stats(path)
        # Папка только с логами/картинками/бинарниками — это не сейвы.
        if total > 0 and meaningful == 0:
            return
        score = _score_candidate(name_score, total, save_files, size, newest, depth)
        existing = candidates.get(key)
        if existing is None or score > existing["score"]:
            candidates[key] = {
                "path": key,
                "score": score,
                "source": source,
                "reason": reason,
                "fileCount": total,
                "saveFileCount": save_files,
                "meaningfulCount": meaningful,
                "size": size,
            }

    # 1. Известные пути из базы (самый надёжный источник)
    for rel in _known_save_paths(game_name, steam_appid):
        resolved = _resolve_known_rel(drive_c, rel, users)
        if resolved is not None:
            add(resolved, 100, "known", 0, f"известный путь: {rel}")

    # 1b. Изученные пользователем пути для похожих игр
    try:
        from learning import suggest_paths
        for learned in suggest_paths(game_name, drive_c):
            add(Path(learned), 100, "learned", 0, "изученный путь")
    except Exception as e:
        logger.debug(f"Learning lookup failed for '{game_name}': {e}")

    # 1f. Эмуляторы с сохранениями в Documents: CPY_SAVES/CPY/<appid>,
    # SKIDROW/<appid> и т.п. App ID берём из steam_appid.txt или из Ludusavi.
    # App ID ярлыка не-Steam игры фейковый (~3.3e9) — для эмуляторов он не
    # подходит, поэтому берём только настоящий (< 3 000 000) или из Ludusavi.
    try:
        emu_appid = int(steam_appid) if steam_appid and int(steam_appid) < 3_000_000 else None
    except (TypeError, ValueError):
        emu_appid = None
    if not emu_appid:
        try:
            from ludusavi import get_steam_id_for_game
            emu_appid = get_steam_id_for_game(game_name)
        except Exception as e:
            logger.debug(f"Ludusavi appid lookup failed for '{game_name}': {e}")
    if emu_appid:
        for user in users:
            docs = drive_c / "users" / user / "Documents"
            if not docs.is_dir():
                continue
            for emu_root in ("CPY_SAVES", "CPY", "SKIDROW", "CODEX", "PLAZA", "EMPRESS", "RUNE", "TENOKE"):
                root = docs / emu_root
                if not root.is_dir():
                    continue
                try:
                    for folder in root.rglob(str(emu_appid)):
                        if folder.is_dir():
                            add(folder, 95, "emulator_docs", 0, f"{emu_root}/{emu_appid}")
                except (PermissionError, OSError):
                    continue

    # 1g. Эмуляторы в Public Documents: users/Public/Documents/Steam/<EMU>/<appid>
    if emu_appid:
        public_docs = drive_c / "users" / "Public" / "Documents"
        if public_docs.is_dir():
            try:
                for folder in public_docs.rglob(str(emu_appid)):
                    if folder.is_dir():
                        add(folder, 95, "emulator_public", 0, f"Public/Steam/{emu_appid}")
            except (PermissionError, OSError):
                pass

    # 1h. Путь из steam_emu.ini (игра/эмулятор сам его прописывает).
    ini_rel = _emu_ini_rel_path(exec_cmd)
    if ini_rel:
        ini_path = _resolve_case_insensitive(drive_c, ini_rel)
        if ini_path is not None and ini_path.is_dir():
            add(ini_path, 95, "emu_ini", 0, f"steam_emu.ini: {ini_rel}")

    # 1d. Steam userdata по реальному App ID (Steam Cloud сейвы)
    for steam_dir in _steam_userdata_dirs(steam_appid):
        add(steam_dir, 90, "steam", 0, f"Steam userdata appid {steam_appid}")

    # 1e. Сохранения рядом с exe игры (save/saves/profile)
    for install_dir in _install_dir_candidates(exec_cmd):
        add(install_dir, 85, "install", 0, f"рядом с игрой: {install_dir.name}")

    # 1c. Сохранения Steam-эмуляторов: AppData/Roaming/<EMU>/<appid>/remote
    for user in users:
        roaming = drive_c / "users" / user / "AppData" / "Roaming"
        if not roaming.is_dir():
            continue
        try:
            for emu in roaming.iterdir():
                if not emu.is_dir() or emu.name.lower() not in EMULATOR_DIRS:
                    continue
                for appid_dir in emu.iterdir():
                    remote = appid_dir / "remote"
                    if not remote.is_dir():
                        continue
                    # Совпадение по реальному App ID — самый точный случай.
                    if steam_appid and str(steam_appid) == appid_dir.name:
                        add(remote, 80, "emulator", 0, f"эмулятор {emu.name}/{appid_dir.name}")
                        continue
                    # Иначе ищем внутри remote подпапку с именем игры
                    # (например, .../Saves/SaveGame/halo4).
                    checked = 0
                    for sub in remote.rglob("*"):
                        checked += 1
                        if checked > 500:
                            break
                        if not sub.is_dir():
                            continue
                        if _name_match_score(game_name, sub.name) >= 85:
                            add(sub, 85, "emulator", 0, f"эмулятор {emu.name}/{appid_dir.name}/{sub.name}")
                            break
        except (PermissionError, OSError):
            continue

    # 2. Эвристика по стандартным корням
    search_names = [n for n in (game_name, prefix_name) if n and n.upper() != "DEFAULT"]
    for root in _candidate_roots(drive_c):
        for search_name in search_names:
            for folder, name_score, depth in _find_named_dirs(root, search_name):
                add(folder, name_score, "heuristic", depth, f"папка '{folder.name}'")

    # Отбрасываем пустые эвристические кандидаты без файлов
    filtered = [
        c for c in candidates.values()
        if c["source"] in ("known", "learned") or c["meaningfulCount"] > 0
    ]
    filtered.sort(key=lambda c: c["score"], reverse=True)
    return filtered[:5]


def detect_save_paths(game_prefix_path: Path, game_name: str = "", steam_appid=None, exec_cmd: str = "") -> List[str]:
    """Автоопределение путей сохранений (список, отсортированный по уверенности)."""
    return [c["path"] for c in detect_save_candidates(game_prefix_path, game_name, steam_appid, exec_cmd)]


def find_game_folders(base_path: Path, game_name: str) -> List[Path]:
    """Найти папки, связанные с игрой по названию (обратная совместимость)."""
    return [folder for folder, _, _ in _find_named_dirs(base_path, game_name, max_depth=1)]


# ---------------------------------------------------------------------------
# Сканирование игр
# ---------------------------------------------------------------------------

def _desktop_dirs(root: Optional[Path]) -> List[Path]:
    """Каталоги, где ищем .desktop файлы игр PortProton."""
    dirs: List[Path] = []
    if root:
        dirs.append(root)
    home = Path.home()
    dirs.append(home / ".local" / "share" / "applications")
    dirs.append(home / "Desktop")
    return dirs


def _collect_desktop_games(root: Optional[Path]) -> List[Dict[str, str]]:
    seen = set()
    games: List[Dict[str, str]] = []
    for directory in _desktop_dirs(root):
        if not directory.is_dir():
            continue
        for desktop_file in directory.glob("*.desktop"):
            if desktop_file.name.lower() in IGNORED_DESKTOP_FILES:
                continue
            # во внешних каталогах берём только записи, связанные с PortProton
            if root and directory != root:
                try:
                    text = desktop_file.read_text(encoding="utf-8", errors="replace").lower()
                except OSError:
                    continue
                if "portproton" not in text:
                    continue
            key = str(desktop_file.resolve())
            if key in seen:
                continue
            info = parse_desktop_file(desktop_file)
            if info:
                seen.add(key)
                games.append(info)
    return games


def discover_prefix_games(prefixes_path: Path, used_prefixes: set) -> List[Dict[str, Any]]:
    """Игры, у которых есть префикс, но нет .desktop файла."""
    games: List[Dict[str, Any]] = []
    for prefix in _iter_prefixes(prefixes_path):
        if prefix.name.upper() == "DEFAULT":
            continue
        if str(prefix.resolve()) in used_prefixes:
            continue
        games.append({
            "name": prefix.name.replace("_", " ").strip() or prefix.name,
            "desktopFile": "",
            "prefixPath": str(prefix),
            "exec": "",
        })
    return games


def scan_portproton_games(force_refresh: bool = False) -> List[Dict[str, Any]]:
    """Сканирование игр PortProton (.desktop + префиксы + Steam-ярлыки) и сохранений."""
    if use_cache and not force_refresh:
        try:
            from cache_manager import cache_manager
            cached = cache_manager.get("portproton_games")
            if cached is not None:
                logger.info("Using cached game list")
                return cached
        except ImportError:
            pass

    portproton_root = find_portproton_root()
    prefixes_path = (portproton_root / "prefixes") if portproton_root else None
    if prefixes_path is None or not prefixes_path.exists():
        logger.warning("PortProton prefixes path not found")
        return []

    # Steam-ярлыки: appid и подсказка о префиксе
    try:
        from steam_shortcuts import find_shortcut_for_game, prefix_hint_from_shortcut
    except Exception as e:
        logger.debug(f"Steam shortcuts unavailable: {e}")
        find_shortcut_for_game = None  # type: ignore
        prefix_hint_from_shortcut = None  # type: ignore

    games: List[Dict[str, Any]] = []
    used_prefixes: set = set()

    # 1. Игры из .desktop файлов
    for info in _collect_desktop_games(portproton_root):
        game_name = info["name"]
        shortcut = find_shortcut_for_game(game_name) if find_shortcut_for_game else None
        hint_path = prefix_hint_from_shortcut(shortcut) if (shortcut and prefix_hint_from_shortcut) else ""

        prefix_path = find_prefix_for_game(
            game_name,
            info.get("desktop_file", ""),
            prefixes_path,
            info.get("exec", ""),
            hint_path,
        )
        if not prefix_path:
            logger.debug(f"No prefix found for game: {game_name}")
            continue

        used_prefixes.add(str(prefix_path.resolve()))
        real_appid = detect_real_steam_appid(info.get("exec", ""))
        lookup_appid = real_appid or (shortcut.get("appid") if shortcut else None)
        candidates = detect_save_candidates(prefix_path, game_name, lookup_appid, info.get("exec", ""))

        game: Dict[str, Any] = {
            "name": game_name,
            "desktopFile": info.get("desktop_file", ""),
            "prefixPath": str(prefix_path),
            "exec": info.get("exec", ""),
            "savePaths": [c["path"] for c in candidates],
            "saveCandidates": candidates,
            "hasSaves": len(candidates) > 0,
        }
        if lookup_appid:
            game["steamAppId"] = lookup_appid
        if real_appid:
            game["realSteamAppId"] = real_appid
            if shortcut and shortcut.get("appid") != real_appid:
                game["shortcutAppId"] = shortcut.get("appid")
        games.append(game)

    # 2. Префиксы без .desktop
    for game in discover_prefix_games(prefixes_path, used_prefixes):
        shortcut = find_shortcut_for_game(game["name"]) if find_shortcut_for_game else None
        if shortcut:
            game["steamAppId"] = shortcut.get("appid")

        candidates = detect_save_candidates(Path(game["prefixPath"]), game["name"], game.get("steamAppId"), game.get("exec", ""))
        game["savePaths"] = [c["path"] for c in candidates]
        game["saveCandidates"] = candidates
        game["hasSaves"] = len(candidates) > 0
        games.append(game)

    # Склеиваем дубли: одна игра может прийти из .desktop файла, из префикса
    # и из второго каталога .desktop. Ключ — нормализованное имя.
    merged: Dict[str, Dict[str, Any]] = {}
    for game in games:
        key = (game.get("name") or "").strip().lower()
        if not key:
            continue
        existing = merged.get(key)
        if existing is None:
            merged[key] = game
            continue
        for path in game.get("savePaths") or []:
            if path not in existing["savePaths"]:
                existing["savePaths"].append(path)
        for candidate in game.get("saveCandidates") or []:
            if all(c.get("path") != candidate.get("path") for c in existing.get("saveCandidates") or []):
                existing.setdefault("saveCandidates", []).append(candidate)
        existing["hasSaves"] = len(existing["savePaths"]) > 0
    games = list(merged.values())

    # Отбрасываем служебные «игры» вроде DEFAULT/DOTNET, которые иногда
    # приходят из .desktop или из имён префиксов.
    def _is_generic(name: str) -> bool:
        lowered = (name or "").lower()
        if any(word in lowered for word in NON_GAME_WORDS):
            return True
        words = [w for w in re.split(r"\s+", lowered) if w]
        return not words or all(w in GENERIC_GAME_NAMES for w in words)

    games = [game for game in games if not _is_generic(game.get("name") or "")]

    # 3. Общий префикс: несколько игр на один префикс.
    # DEFAULT — штатный общий префикс PortProton, предупреждение про него
    # показывать бессмысленно: иначе оно висит почти на каждой игре.
    by_prefix: Dict[str, List[str]] = {}
    for game in games:
        by_prefix.setdefault(game["prefixPath"], []).append(game["name"])
    for game in games:
        if Path(game["prefixPath"]).name.upper() == "DEFAULT":
            continue
        shared = by_prefix.get(game["prefixPath"], [])
        if len(shared) > 1:
            game["sharedPrefix"] = True
            game["sharedWith"] = [n for n in shared if n != game["name"]][:5]

    games.sort(key=lambda g: g["name"].lower())

    if use_cache:
        try:
            from cache_manager import cache_manager
            cache_manager.set("portproton_games", games)
        except ImportError:
            pass

    logger.info(f"Found {len(games)} PortProton games")
    return games
